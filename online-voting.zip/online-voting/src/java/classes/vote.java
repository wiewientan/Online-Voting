///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package classes;
//import java.sql.Timestamp;
//
///**
// *
// * @author NHT-Dilshan
// */
//public class vote {
//    
//    
//
//public class Vote {
//    private int voteId;
//    private int electionId;
//    private int voterId;
//    private int candidateId;
//    private Timestamp timestamp;
//
//    // Constructors
//    public Vote() {}
//
//    public Vote(int voteId, int electionId, int voterId, int candidateId, Timestamp timestamp) {
//        this.voteId = voteId;
//        this.electionId = electionId;
//        this.voterId = voterId;
//        this.candidateId = candidateId;
//        this.timestamp = timestamp;
//    }
//
//    // Getters and Setters
//    public int getVoteId() { return voteId; }
//    public void setVoteId(int voteId) { this.voteId = voteId; }
//    public int getElectionId() { return electionId; }
//    public void setElectionId(int electionId) { this.electionId = electionId; }
//    public int getVoterId() { return voterId; }
//    public void setVoterId(int voterId) { this.voterId = voterId; }
//    public int getCandidateId() { return candidateId; }
//    public void setCandidateId(int candidateId) { this.candidateId = candidateId; }
//    public Timestamp getTimestamp() { return timestamp; }
//    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }
//
//    // Methods
//    public boolean castVote() {
//        // Implementation for casting vote
//        return true;
//    }
//
//    public boolean validateVote() {
//        // Implementation for validating vote
//        return true;
//    }
//}
//    
//}
